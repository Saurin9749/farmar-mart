package com.farmar_mart.agriculture_order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgricultureApplicationTests {

	@Test
	void contextLoads() {
	}

}
