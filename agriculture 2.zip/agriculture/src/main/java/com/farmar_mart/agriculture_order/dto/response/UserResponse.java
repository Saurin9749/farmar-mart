package com.farmar_mart.agriculture_order.dto.response;

public class UserResponse {
    private long id;
    private String name;
    private String email;
}
